#!/usr/local/bin/python
# -*- coding: utf-8 -*-
'''
Author: zhoushuke
Email: zhoushuke@sensetime.com
Date: 2021-04-26 14:54:48
LastEditors: zhoushuke
LastEditTime: 2021-04-26 17:32:22
FilePath: /fallen_deliver/fallendeliver/__version__.py
'''

__version__ = "0.1.0"
